import type { ExtensionCapability } from "./capabilities.js";
import type { ExtensionCompatibility } from "./compatibility.js";
import type { ExtensionContributions } from "./contributions.js";
import type { ExtensionEntrypoint, ExtensionDistribution } from "./entry.js";
import type { ExtensionI18nDefinition, I18nLabel } from "./i18n.js";
import type { ExtensionIcon } from "./icon.js";
import type { ExtensionIntegrity } from "./integrity.js";
import type { ExtensionSettingsSchema } from "./settings.js";
import type { ExtensionSupportDeclaration } from "./support.js";
import type { ExtensionManifestVersion } from "./version.js";

export type ExtensionKind = "bundled" | "external";

export interface ExtensionManifest {
  readonly manifestVersion: ExtensionManifestVersion | number;
  readonly id: string;
  readonly packageName: string;
  readonly version: string;
  readonly displayName: I18nLabel;
  readonly description: I18nLabel;
  readonly kind: ExtensionKind;
  readonly publisher?: string;
  readonly license?: string;
  readonly homepage?: string;
  readonly repository?: string;
  readonly categories?: readonly string[];
  readonly keywords?: readonly string[];
  readonly icon: ExtensionIcon;
  readonly enabledByDefault: boolean;
  readonly capabilities: readonly ExtensionCapability[];
  readonly compatibility: ExtensionCompatibility;
  readonly entry: ExtensionEntrypoint;
  readonly contributions: ExtensionContributions;
  readonly settingsSchema?: ExtensionSettingsSchema;
  readonly i18n?: ExtensionI18nDefinition;
  readonly distribution?: ExtensionDistribution;
  readonly integrity?: ExtensionIntegrity;
  readonly support?: ExtensionSupportDeclaration;
}
