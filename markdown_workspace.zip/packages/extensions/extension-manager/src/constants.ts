export const EXTENSION_MANAGER_EXTENSION_ID = "core.extension-manager" as const;
export const EXTENSION_MANAGER_VIEW_ID = `${EXTENSION_MANAGER_EXTENSION_ID}.view` as const;
export const EXTENSION_MANAGER_COMMAND_ID = `${EXTENSION_MANAGER_EXTENSION_ID}.open` as const;
export const EXTENSION_MANAGER_RAIL_ID = `${EXTENSION_MANAGER_EXTENSION_ID}.rail` as const;
