import type { I18nLabel } from "@markdown-workspace/extension-manifest";
import type { ExtensionLocaleCatalogLoader } from "@markdown-workspace/extension-host";
import { EXTENSION_MANAGER_EXTENSION_ID } from "./constants.js";

const key = (suffix: string) => `${EXTENSION_MANAGER_EXTENSION_ID}.${suffix}`;
export const emLabel = (suffix: string, defaultMessage: string, description?: string): I18nLabel => ({
  key: key(suffix),
  defaultMessage,
  description,
});

export const extensionManagerLabels = {
  manifestDisplayName: emLabel("manifest.displayName", "Extension Manager"),
  manifestDescription: emLabel("manifest.description", "Bundled operator console for browsing, enabling, disabling, diagnosing, and configuring extensions."),
  commandOpenTitle: emLabel("commands.open.title", "Open Extension Manager"),
  commandOpenDescription: emLabel("commands.open.description", "Open the bundled extension operator console."),
  viewTitle: emLabel("views.manager.title", "Extension Manager"),
  viewDescription: emLabel("views.manager.description", "Browse installed extensions, toggle enablement, inspect permissions, and edit extension settings."),
  railTitle: emLabel("rail.title", "Extensions"),
  settingsTitle: emLabel("settings.title", "Extension Manager Preferences"),
  settingsDisplayTitle: emLabel("settings.sections.display.title", "Display"),
  settingsDisplayDescription: emLabel("settings.sections.display.description", "Controls the default information density for the extension manager."),
  showCompatibilityLabel: emLabel("settings.fields.showCompatibilityByDefault.label", "Show compatibility details by default"),
  showCompatibilityDescription: emLabel("settings.fields.showCompatibilityByDefault.description", "Expand compatibility information for each extension when the manager opens."),
  showDiagnosticsLabel: emLabel("settings.fields.showDiagnosticsByDefault.label", "Show diagnostics by default"),
  showDiagnosticsDescription: emLabel("settings.fields.showDiagnosticsByDefault.description", "Expand runtime diagnostics for each extension when the manager opens."),
  headerTitle: emLabel("view.header.title", "Extension Manager"),
  headerSubtitle: emLabel("view.header.subtitle", "Bundled extension catalog, enablement controls, permissions, compatibility, diagnostics, and settings."),
  actionExit: emLabel("view.actions.exit", "Exit"),
  actionClose: emLabel("view.actions.close", "Close"),
  statsExtensions: emLabel("view.stats.extensions", "Extensions"),
  statsActive: emLabel("view.stats.active", "Active"),
  statsDisabled: emLabel("view.stats.disabled", "Disabled"),
  statsIncompatible: emLabel("view.stats.incompatible", "Incompatible"),
  sourceBundled: emLabel("view.card.source.bundled", "Bundled"),
  sourceInstalled: emLabel("view.card.source.installed", "Installed"),
  actionEnable: emLabel("view.card.actions.enable", "Enable"),
  actionDisable: emLabel("view.card.actions.disable", "Disable"),
  actionActivate: emLabel("view.card.actions.activate", "Activate"),
  actionDeactivate: emLabel("view.card.actions.deactivate", "Deactivate"),
  labelPackage: emLabel("view.card.labels.package", "Package"),
  labelVersion: emLabel("view.card.labels.version", "Version"),
  labelActivation: emLabel("view.card.labels.activation", "Activation"),
  labelEnabled: emLabel("view.card.labels.enabled", "Enabled"),
  labelPermissions: emLabel("view.card.labels.permissions", "Permissions"),
  labelCompatibility: emLabel("view.card.labels.compatibility", "Compatibility"),
  labelHealth: emLabel("view.card.labels.health", "Health & diagnostics"),
  labelSettings: emLabel("view.card.labels.settings", "Settings"),
  stateEnabled: emLabel("view.card.state.enabled", "yes"),
  stateDisabled: emLabel("view.card.state.disabled", "no"),
  compatibilityOk: emLabel("view.card.compatibility.ok", "Compatible with the current host, runtime, and theme contract."),
  compatibilityError: emLabel("view.card.compatibility.error", "One or more compatibility issues were detected."),
  noDiagnostics: emLabel("view.card.health.noDiagnostics", "No runtime diagnostics recorded."),
  lastError: emLabel("view.card.health.lastError", "Last error"),
  settingsEnabled: emLabel("settings.form.state.enabled", "Enabled"),
  settingsDisabled: emLabel("settings.form.state.disabled", "Disabled"),
  readyDiagnostic: emLabel("diagnostics.ready", "Extension Manager activated successfully."),
} as const;

export const extensionManagerLocaleLoader: ExtensionLocaleCatalogLoader = {
  defaultLocale: "en",
  fallbackLocale: "en",
  loaders: {
    en: async () => (await import("./locales/en.js")).extensionManagerEnCatalog,
    es: async () => (await import("./locales/es.js")).extensionManagerEsCatalog,
  },
};
