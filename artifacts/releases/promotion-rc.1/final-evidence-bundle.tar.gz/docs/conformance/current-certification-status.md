# Current certification status

Date: 2026-03-30

## Summary

This repository checkpoint is a **Phase 14 promotion and release checkpoint** built on top of:

- the existing v2 monorepo and publish-stability / extension-distribution work
- the Phase 0 certification-target freeze
- the Phase 1 release-train freeze
- the Phase 2 renderer/CommonMark-core checkpoint
- the Phase 3 default-GFM checkpoint
- the Phase 4 optional-profile checkpoint
- the Phase 5 editor semantics and authoring UX checkpoint
- the Phase 6 preview/export/render-policy checkpoint
- the Phase 7 shell parity checkpoint
- the Phase 8 settings/data/session/Git parity checkpoint
- the Phase 9 theme inventory/token contract/visual parity checkpoint
- the Phase 10 i18n/language UX/catalog coverage checkpoint
- the Phase 11 package documentation/examples/boundary/evidence checkpoint
- the Phase 12 strict conformance closure-suite checkpoint
- the Phase 13 RC freeze/versioning/promotion-prep checkpoint

It is **not yet certified** as:

- certifiably fully featured
- repository-internal RFC compliant for the full frozen boundary
- Markdown spec compliant for the full frozen CommonMark/GFM target

## What is now true in this checkpoint

- the external Markdown target remains explicitly frozen as CommonMark 0.31.2 core plus GFM 0.29-gfm as the default profile
- the repository still carries the frozen release-train document, release-group matrix, compatibility-baseline policy, and living v1→v2 gap ledger
- the implementation checkpoints through Phase 13 remain present and recorded in the repository
- the repository now also carries a generated Phase 14 promotion bundle that aggregates publish order, publish-readiness, release evidence, extension catalog promotion metadata, tarball bundles, Git tag / GitHub release metadata, and final release notes with explicit claim boundaries
- the Phase 12 closure suite remains the last strict-conformance gate and still records **9 green closure lanes**, **3 blocked closure lanes**, **4 green hard-closure rules**, and **1 blocked hard-closure rule**
- the Phase 13 RC train remains prepared but not accepted because browser matrix, browser-driven visual regression, full frozen-target corpus closure, and publish readiness remained blocked
- Phase 14 does not hide those blockers; it packages them into an explicit promotion-and-release bundle and keeps the release claim language aligned with the current evidence

## Evidence now present in the repository

The repository now contains all of the following latest promotion/release checkpoint artifacts:

- `PHASE_14_CHECKPOINT_SUMMARY.md`
- `docs/adr/ADR-0021-promotion-and-release-phase14-checkpoint.md`
- `docs/current-state/phase-14-promotion-assessment.md`
- `docs/conformance/promotion-release-phase14.md`
- `artifacts/conformance/latest/phase-14-promotion-release-checkpoint.json`
- `artifacts/conformance/latest/phase-14-promotion-release-results.json`
- `artifacts/conformance/latest/phase-14-publish-order.json`
- `artifacts/conformance/latest/phase-14-published-packages.json`
- `artifacts/conformance/latest/phase-14-extension-catalog.json`
- `artifacts/conformance/latest/phase-14-git-tag-metadata.json`
- `artifacts/conformance/latest/phase-14-github-release-metadata.json`
- `artifacts/conformance/latest/phase-14-release-notes.md`
- `artifacts/conformance/latest/phase-14-published-artifact-compatibility.json`
- `artifacts/releases/promotion-rc.1/`

The executed promotion lane is backed by:

- `npm run publish:packages`
- `npm run release:evidence`
- `node tools/conformance/generate-phase14-promotion-checkpoint.mjs`

## Why certification is still not claimed

The repository is materially stronger and more release-ready than it was in Phase 13, but final closure and public publication are still open.

The primary open categories are:

- the current corpus lanes are still explicit subset lanes rather than a full official end-to-end frozen-target corpus/program for every declared profile path
- the browser matrix lane is blocked in the current environment
- the visual regression lane is still limited to structural smoke plus static HTML baselines rather than browser-driven pixel diffs
- the packed tarball install lane is still blocked for the full app release set in the current environment
- npm publication is blocked without an auth token
- Git tag creation and GitHub release creation are blocked because the checkpoint zip does not include a Git repository / remote-auth context

## Honest status

This update is a valid and useful **Phase 14 promotion and release checkpoint**.
It should be treated as the canonical Phase 14 promotion bundle for a later real release environment, not as proof that the repository has already completed publication or final certification closure.

## Key documents for this checkpoint

- `PHASE_14_CHECKPOINT_SUMMARY.md`
- `docs/adr/ADR-0021-promotion-and-release-phase14-checkpoint.md`
- `docs/current-state/phase-14-promotion-assessment.md`
- `docs/conformance/promotion-release-phase14.md`
- `artifacts/conformance/latest/phase-14-promotion-release-checkpoint.json`
- `artifacts/conformance/latest/phase-14-promotion-release-results.json`
- `artifacts/releases/promotion-rc.1/README.md`
