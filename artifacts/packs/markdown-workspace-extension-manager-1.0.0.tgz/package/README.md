# @markdown-workspace/extension-manager

First-party bundled operator console extension for Markdown Workspace.

## Purpose

This package provides the initial Extension Manager experience required to prove the runtime platform with a real bundled extension.

It registers:
- an Extension Manager view
- an Extension Manager action-rail entry
- an open-manager command
- package-local locale catalogs for localized labels and UI text

The manager view shows:
- bundled extension inventory
- enabled/disabled state
- activation mode and status
- compatibility state
- granted and missing capabilities
- runtime diagnostics and last-error data
- schema-driven settings forms for extensions that declare `settingsSchema`

## Public exports

- `createExtensionManagerBundledEntry()`
- `EXTENSION_MANAGER_EXTENSION_ID`
- `EXTENSION_MANAGER_VIEW_ID`
- `EXTENSION_MANAGER_COMMAND_ID`
- `extensionManagerManifest`
- `extensionManagerLabels`
- `extensionManagerLocaleLoader`

## Current status

Implemented in Phase 9.

This package is publishable and intended for first-party bundling. It does **not** yet implement remote catalog installation or third-party certification flows.
