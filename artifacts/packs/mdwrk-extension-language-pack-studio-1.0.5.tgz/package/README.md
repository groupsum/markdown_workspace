# @mdwrk/extension-language-pack-studio

**Language-pack authoring extension**

<p align="center">
  <a href="https://github.com/groupsum/markdown_workspace/blob/master/packages/extensions/extension-language-pack-studio/README.md"><img alt="Hits" src="https://visitor-badge.laobi.icu/badge?page_id=groupsum.markdown_workspace.packages_extensions_extension_language_pack_studio_README&amp;left_text=hits" /></a>
  <a href="https://www.npmjs.com/package/@mdwrk/extension-language-pack-studio"><img alt="Downloads" src="https://img.shields.io/npm/dm/%40mdwrk%2Fextension-language-pack-studio?label=downloads" /></a>
  <a href="../../../package.json"><img alt="Node" src="https://img.shields.io/badge/node-20.x%20%7C%2021.x%20%7C%2022.x-339933?logo=node.js&amp;logoColor=white" /></a>
  <a href="../../../LICENSE"><img alt="License: Apache-2.0" src="https://img.shields.io/badge/license-Apache--2.0-blue.svg" /></a>
</p>

This package provides the first-party extension for inspecting and shaping language-pack data inside MdWrk hosts.

## Why
Use it when localization authoring should remain an extension concern instead of being hard-wired into the app shell.

## What
- Bundled extension entrypoints and language-pack helpers.
- A first-party consumer of the i18n package family and host APIs.
- A workspace authoring surface for localization-related workflows.

## Installation
Node.js 20.x through 22.x, matching the workspace engine contract in the root package manifest.

```bash
npm install @mdwrk/extension-language-pack-studio @mdwrk/i18n
```

## Usage
Load it as a bundled extension in a host with i18n and workspace capabilities.

## Related
- [Packages index](../../README.md) - family and package navigation
- [Root README](../../../README.md) - repo overview
