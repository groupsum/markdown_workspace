# @markdown-workspace/extension-manifest

Normative manifest, settings, capability, i18n, icon, contribution, distribution, integrity, support, and compatibility contracts for Markdown Workspace extensions.

## Package purpose

This package is the authoring source of truth for extension metadata and manifest structure.

## What it exports

- manifest version constants
- extension manifest interface
- capabilities
- contribution descriptors
- settings schema types
- i18n label types
- icon descriptors
- compatibility declarations
- distribution and integrity metadata
- support declaration types

## Intended consumers

- extension packages
- extension runtime packages
- manifest validators
- documentation and schema tooling

## Build

```bash
npm run build -w @markdown-workspace/extension-manifest
```

## Publishability

This package is structured as a standalone publishable npm package with typed exports and generated build output under `dist/`.
