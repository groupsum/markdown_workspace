# @markdown-workspace/extension-runtime

Portable extension runtime for Markdown Workspace hosts.

This package provides:
- extension catalog registration for bundled extensions
- manifest validation
- host/runtime compatibility checks
- persisted enabled/config state with deterministic namespaced keys
- activation and deactivation lifecycle management
- capability-scoped host wrappers
- runtime diagnostics and state snapshots

This checkpoint package is sufficient for Phase 7 host integration and testing. It is not yet the full third-party catalog installer described in later ADRs.
